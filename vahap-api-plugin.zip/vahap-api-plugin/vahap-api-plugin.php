<?php
/*
Plugin Name: Vahap API Plugin
Description: WPCenter Backend Developer Test Project
Version: 1.0
Author: Vahap Karaağaç
*/

function vahap_api_plugin_enqueue_scripts() {

    wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

    wp_enqueue_script('vahap-api-script', plugin_dir_url(__FILE__) . 'js/vahap-api-script.js', array('jquery'), '1.0', true);

    wp_enqueue_script('bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), '4.5.2', true);

    wp_localize_script('vahap-api-script', 'customApiSettings', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'vahap_api_plugin_enqueue_scripts');

function vahap_api_plugin_create_endpoint() {
    register_rest_route('vahap-api-plugin/v1', '/user-details', array(
        'methods' => 'GET',
        'callback' => 'vahap_api_plugin_get_user_details',
    ));
}

add_action('rest_api_init', 'vahap_api_plugin_create_endpoint');

function vahap_api_plugin_localize_script() {
    wp_enqueue_script('vahap-api-script');
    wp_localize_script('vahap-api-script', 'customApiSettings', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'vahap_api_plugin_localize_script');

function vahap_api_plugin_register_shortcode() {
    add_shortcode('vahap_api_plugin', 'vahap_api_plugin_shortcode_handler');
}

function vahap_api_plugin_shortcode_handler() {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/user-details-template.php');
    return ob_get_clean();
}

add_action('init', 'vahap_api_plugin_register_shortcode');
