<?php

$api_url = "https://jsonplaceholder.typicode.com/users";

$response = wp_safe_remote_get($api_url);
$body = wp_remote_retrieve_body($response);
$user_data = json_decode($body);

echo '<div class="table-responsive">';
echo '<table class="table table-bordered table-hover">';
echo '<thead class="thead-dark">';
echo '<tr><th class="col-3">Name</th><th class="col-3">Username</th><th class="col-3">Phone</th><th class="col-3">Email</th></tr>';
echo '</thead>';
echo '<tbody>';

foreach ($user_data as $user) {
    echo '<tr onclick="vahap(' . esc_attr($user->id) . ')" class="clickable-row" data-user-id="' . esc_attr($user->id) . '">';
    echo '<td>' . esc_html($user->name) . '</td>';
    echo '<td>' . esc_html($user->username) . '</td>';
    echo '<td>' . esc_html($user->phone) . '</td>';
    echo '<td>' . esc_html($user->email) . '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>';
?>

<!-- Bootstrap Card Popup -->
<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModalLabel">User Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="userDetailsCard" class="card">
                    <div class="card-body">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script src="../js/vahap-api-script.js"></script>

