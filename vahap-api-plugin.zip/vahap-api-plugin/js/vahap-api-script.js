jQuery(document).ready(function($) {
    
    
    $('.vahap-api-plugin-table').click(function(event) {
        event.preventDefault();
        
        var button = $(this);
        var userId = button.data('user-id');
        var table = button.closest('.vahap-api-plugin-table-container').find('.vahap-api-plugin-data-table');

        $.ajax({
            url: customApiSettings.ajaxUrl,
            type: 'GET',
            data: {
                action: 'vahap_api_plugin_get_user_details',
                user_id: userId,
            },
            success: function(response) {
                table.html(response);
            },
        });
    });
});

function vahap(id) {
    $.ajax({
        url: 'https://jsonplaceholder.typicode.com/users/' + id,
        type: 'GET',
        success: function(response) {
            $('#userDetailsCard .card-body').html('');
            $('#userDetailsCard .card-body').append('<h5 class="card-title">' + response.name + '</h5>');
            $('#userDetailsCard .card-body').append('<p class="card-text"><strong>Username:</strong> ' + response.username + '</p>');
            $('#userDetailsCard .card-body').append('<p class="card-text"><strong>Phone:</strong> ' + response.phone + '</p>');
            $('#userDetailsCard .card-body').append('<p class="card-text"><strong>Email:</strong> ' + response.email + '</p>');
            var addressHTML = '<p class="card-text"><strong>Address:</strong> ' + response.address.street + ', ' + response.address.suite + ', ' + response.address.city + ', ' + response.address.zipcode + '</p>';
            $('#userDetailsCard .card-body').append(addressHTML);
            $('#userDetailsCard .card-body').append('<p class="card-text"><strong>Website:</strong> ' + response.website + '</p>');
            var companyHTML = '<p class="card-text"><strong>Company:</strong> ' + response.company.name + ', ' + response.company.catchPhrase + ', ' + response.company.bs + '</p>';
            $('#userDetailsCard .card-body').append(companyHTML);
            $('#userModal').modal('show'); // Popup aç
        },
        error: function() {
            alert('Error fetching user details.');
        }
    });
}